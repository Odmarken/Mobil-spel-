# Eastvale Legion — Book I

Single-file HTML game ready for GitHub Pages.

## Play locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `eastvale-legion`.
2. Upload all files in this folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/root**, then press **Save**.
6. Open the Pages link when GitHub shows it.

## iPhone app style
Open the Pages link in Safari, press **Share**, then **Add to Home Screen**.
